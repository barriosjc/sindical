@extends('layouts.admin')

@section('main-content')

<div class="container">
    <div class="card">
        <div class="card-header">
            Novedades
        </div>
        <ul class="list-group list-group-flush">
            <li class="list-group-item">02/02/2023 - Se exportaron todos los datos de Gestión a este sistema web que lo llamaremos Sindical Avellaneda, a partir de ahora solo se usa este sistema como productivo.</li>
            <li class="list-group-item">02/02/2023 - Sistema de Gestión solo se debe utilizar para realizar consultas, no se debe guardar datos</li>
        </ul>
    </div>
</div>

@endsection